"""
Every write and business rule of the bookings app.

Life of a booking (BR-BKG-06, table 7a):

    quote --create_booking--> pending --accept--> confirmed --job--> completed
                                 |  \\--decline--> declined
                                 |   \\--job-----> expired
                                 \\--cancel-----> cancelled <--cancel-- confirmed

Rules applied here:
- BR-BKG-01/02: instant only when the listing (or trip) resolves to instant,
  the platform switch allows it and the host's deposit is above its floor
  (BR-PAY-10); otherwise the booking is a request;
- BR-BKG-03/04: a request blocks the dates until answered, and expires after
  ``request_ttl_hours`` (DEC-008) or at check-in time if sooner;
- BR-BKG-05: a confirmed stay completes at check-out time + 2 hours (Algiers);
- BR-BKG-07: price, commission rate and policy windows are frozen at creation;
- BR-AVL-01/02: no overlapping stay on a home, no oversold room or seat;
- BR-CAN-01 to 03: refund owed by the host after a cancellation (DEC-001),
  tracked as a debt with a deadline (review R8);
- BR-PAY-04/05, DEC-018 revised 2026-11-13: commission taken at
  confirmation; after a cancellation the commission follows the refund
  (guest cancels: same share as the refunded subtotal; host cancels: all of
  it); nothing to return on decline or expiry, none was taken;
- review R7: the host wallet row is locked first, then the booking and the
  stock, in every function that can move money;
- review R13: open bookings per guest are limited, and a review needs a
  confirmed stay (check-in code or guest confirmation);
- review R3: every room change of a connected hotel is pushed to its system
  through the outbox.

Every function that writes runs inside ``transaction.atomic`` and reads the
booking with ``select_for_update`` so two actions cannot cross.
"""

import secrets
import uuid
from datetime import datetime, time, timedelta

from django.db import transaction
from django.utils import timezone

from apps.accounts.models import User
from apps.audit import services as audit
from apps.catalog.models import POLICY_WINDOWS, Listing
from apps.config import services as config
from apps.core.errors import ConflictError, DomainError, ForbiddenError, NotFoundError
from apps.core.ids import human_reference
from apps.core import outbox
from apps.core.money import apply_bp
from apps.core.timeutils import business_datetime, business_today, business_tz
from apps.hosts.models import ApprovalMode
from apps.hosts.models import PropertyIntegration
from apps.hosts.selectors import host_accounts_for
from apps.inventory import services as inventory
from apps.inventory.selectors import blocked_days
from apps.ledger import services as ledger
from apps.pricing import services as pricing
from apps.pricing.models import Quote
from apps.pricing.services import PriceResult
from apps.trips import services as trips

from . import selectors
from .models import (
    BLOCKING_STATUSES,
    ActorRole,
    Booking,
    BookingEvent,
    BookingStatus,
    InventoryKind,
    RefundObligation,
    RefundStatus,
    StayConfirmedVia,
    UNPAID_REFUND_STATUSES,
    can_transition,
)

# Times used when a listing has no check-in or check-out time of its own.
DEFAULT_CHECK_IN_TIME = time(15, 0)
DEFAULT_CHECK_OUT_TIME = time(11, 0)
# Trips have dates only: they are taken to start in the morning and end in the evening.
TRIP_START_TIME = time(8, 0)
TRIP_END_TIME = time(18, 0)
# BR-BKG-05: a stay completes 2 hours after check-out time.
COMPLETION_DELAY = timedelta(hours=2)


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def _new_reference() -> str:
    """A booking reference ``BLD-<year>-XXXXXX`` not used yet (BR-BKG-07, BKG-08)."""
    year = business_today().year
    for _ in range(10):
        ref = human_reference("BLD", year)
        if not Booking.objects.filter(reference=ref).exists():
            return ref
    raise RuntimeError("Could not generate a unique booking reference.")


def _clean_reason(reason: str | None) -> str:
    """A reason is required for decline and host or admin cancellation (BR-BKG-03, BR-CAN-03/04)."""
    text = (reason or "").strip()
    if not text:
        raise DomainError("Give a reason.", code="reason_required", errors={"reason": ["Required."]})
    return text


def _lock(booking: Booking) -> Booking:
    """
    Lock the host wallet, then re-read the booking with a row lock (review R7).

    Every action that may move money takes the locks in this order (wallet,
    then booking, then stock), so two actions never wait for each other in
    a circle and two actions on one booking run one after the other.
    """
    ledger.lock_wallet(booking.host_account)
    return Booking.objects.select_for_update().get(pk=booking.pk)


def _new_check_in_code() -> str:
    """6-digit code the guest shows on arrival; the host enters it to confirm the stay (review R13)."""
    return f"{secrets.randbelow(1_000_000):06d}"


def has_overdue_refund(host_account) -> bool:
    """True when the host still owes a guest a refund after its deadline (review R8)."""
    return RefundObligation.objects.filter(
        host_account=host_account, status__in=UNPAID_REFUND_STATUSES, due_at__lte=timezone.now()
    ).exists()


def _check_guest_limits(guest) -> None:
    """
    Refuse a new booking when the guest already holds too many (review R13).

    Limits from the settings: ``max_pending_requests_per_guest`` waiting
    requests, and ``max_upcoming_bookings_per_guest`` pending or confirmed
    bookings that are not finished yet. Stops a guest from blocking many
    dates for free. The guest row is locked so two parallel requests count
    each other. Error ``too_many_open_bookings`` (409).
    """
    User.objects.select_for_update().filter(pk=guest.pk).first()
    today = business_today()
    open_qs = Booking.objects.filter(guest=guest, check_out__gte=today)
    pending = open_qs.filter(status=BookingStatus.PENDING).count()
    upcoming = open_qs.filter(status__in=[BookingStatus.PENDING, BookingStatus.CONFIRMED]).count()
    if pending >= int(config.get_value("max_pending_requests_per_guest")) or \
            upcoming >= int(config.get_value("max_upcoming_bookings_per_guest")):
        raise ConflictError("You already have too many open bookings. Finish or cancel one first.",
                            code="too_many_open_bookings")


def _announce_room_change(booking: Booking) -> None:
    """
    Queue a push of the free rooms to the hotel's own system (review R3, DEC-017).

    Only for room pools of an organisation with an active integration. The
    message is written in the same transaction as the booking change and
    delivered by the outbox worker, with retries.
    """
    if booking.inventory_kind != InventoryKind.ROOM_POOL or not booking.host_account.organization_id:
        return
    nights = [booking.check_in.fromordinal(day) for day in
              range(booking.check_in.toordinal(), booking.check_out.toordinal())]
    for integration in PropertyIntegration.objects.filter(organization_id=booking.host_account.organization_id,
                                                          status="active"):
        outbox.enqueue("inventory.push", {
            "integration_id": str(integration.id), "room_type_id": str(booking.room_type_id),
            "nights": [n.isoformat() for n in nights], "booking": booking.reference,
        })


def _time_text(value: time) -> str:
    """``HH:MM`` text of a time, as stored in the snapshot."""
    return value.strftime("%H:%M")


def check_in_at(booking: Booking) -> datetime:
    """Aware date and time of arrival in Algeria (check-in day + check-in time from the snapshot)."""
    at = time.fromisoformat(booking.listing_snapshot.get("check_in_time") or _time_text(DEFAULT_CHECK_IN_TIME))
    return business_datetime(booking.check_in, at)


def check_out_at(booking: Booking) -> datetime:
    """Aware date and time of departure in Algeria (check-out day + check-out time from the snapshot)."""
    at = time.fromisoformat(booking.listing_snapshot.get("check_out_time") or _time_text(DEFAULT_CHECK_OUT_TIME))
    return business_datetime(booking.check_out, at)


def _is_own_offer(guest, host_account) -> bool:
    """True when the guest is the host, or a member of the host organisation (they may not book themselves)."""
    return any(account.id == host_account.id for account, _ in host_accounts_for(guest))


def _snapshot(result: PriceResult) -> tuple[dict, list]:
    """
    What the booking keeps from the listing or trip at creation (BR-BKG-07):
    title, reference, private address and point (shown once confirmed,
    BR-SRC-03), check-in and check-out times; plus the policy windows (BR-CAN-01).
    """
    if result.trip_departure is not None:
        trip = result.trip_departure.trip
        policy = trip.cancellation_policy
        data = {
            "vertical": "trip", "title": trip.title, "reference": trip.reference, "trip_id": str(trip.id),
            "address_line": trip.meeting_point_text,
            "latitude": str(trip.meeting_point_latitude) if trip.meeting_point_latitude is not None else None,
            "longitude": str(trip.meeting_point_longitude) if trip.meeting_point_longitude is not None else None,
            "check_in_time": _time_text(TRIP_START_TIME), "check_out_time": _time_text(TRIP_END_TIME),
        }
    else:
        listing = result.listing
        policy = listing.cancellation_policy
        if result.experience_slot is not None:
            # A session starts and ends at its own times (read in Algerian time).
            tz = business_tz()
            check_in_time = result.experience_slot.starts_at.astimezone(tz).time()
            check_out_time = result.experience_slot.ends_at.astimezone(tz).time()
        else:
            check_in_time = listing.check_in_time or DEFAULT_CHECK_IN_TIME
            check_out_time = listing.check_out_time or DEFAULT_CHECK_OUT_TIME
        data = {
            "vertical": listing.vertical, "title": listing.title, "reference": listing.reference,
            "address_line": listing.address_line,
            "commune": listing.commune.name_fr if listing.commune_id else None,
            "latitude": str(listing.latitude) if listing.latitude is not None else None,
            "longitude": str(listing.longitude) if listing.longitude is not None else None,
            "room_type_name": result.room_type.name if result.room_type else None,
            "check_in_time": _time_text(check_in_time), "check_out_time": _time_text(check_out_time),
        }
    data["policy_code"] = policy.code if policy else "moderate"
    data["policy_version"] = policy.version if policy else None
    # Without a policy, use the moderate windows (the default of new listings and trips).
    windows = policy.windows if policy else POLICY_WINDOWS["moderate"]
    return data, list(windows)


def _record_event(booking: Booking, from_status: str, *, actor, role: str, note: str = "") -> None:
    """Append one line to the booking history (BR-BKG-06)."""
    BookingEvent.objects.create(booking=booking, from_status=from_status, to_status=booking.status,
                                actor=actor, actor_role=role, note=note)


def _transition(booking: Booking, new_status: str, *, actor, role: str, note: str = "", fields: tuple = ()) -> None:
    """
    Move a locked booking to ``new_status`` if table 7a allows it (BR-BKG-06),
    set the matching timestamp, save ``fields`` too, and write the history line.
    """
    old = booking.status
    if not can_transition(old, new_status):
        raise ConflictError(f"A {old} booking cannot become {new_status}.", code="invalid_transition")
    now = timezone.now()
    booking.status = new_status
    changed = ["status", "updated_at", *fields]
    stamp = {BookingStatus.CONFIRMED: "confirmed_at", BookingStatus.COMPLETED: "completed_at",
             BookingStatus.CANCELLED: "cancelled_at"}.get(new_status)
    if stamp:
        setattr(booking, stamp, now)
        changed.append(stamp)
    booking.save(update_fields=changed)
    _record_event(booking, old, actor=actor, role=role, note=note)


# ---------------------------------------------------------------------------
# Inventory
# ---------------------------------------------------------------------------
def _single_unit_overlaps(listing_id, check_in, check_out) -> bool:
    """True when a blocking booking of this home overlaps ``[check_in, check_out)`` (back-to-back is fine, BR-AVL-01)."""
    return Booking.objects.filter(
        listing_id=listing_id, inventory_kind=InventoryKind.SINGLE, status__in=BLOCKING_STATUSES,
        check_in__lt=check_out, check_out__gt=check_in,
    ).exists()


def _reserve(kind: str, result: PriceResult) -> None:
    """
    Take the stock of a new booking (BR-AVL-01, BR-AVL-02).

    Single unit: lock the listing row, then refuse an overlapping blocking
    booking or a blocked day (the lock makes two guests, or a guest and the
    host closing days, wait for each other; on PostgreSQL the exclusion
    constraint and the triggers of migration 0003 back it up).
    Pools: one conditional ``UPDATE`` in inventory or trips. Pending
    requests count as ``booked`` too: a request keeps the dates blocked
    until it is answered or expires (BR-BKG-03); ``held`` is kept for the
    15-minute payment holds of BR-AVL-06, which do not exist yet.
    """
    if kind == InventoryKind.SINGLE:
        Listing.objects.select_for_update().filter(pk=result.listing.pk).first()
        # Review R2: re-check host blocks under the same lock the calendar uses.
        if _single_unit_overlaps(result.listing.pk, result.check_in, result.check_out) or \
                blocked_days(result.listing, result.check_in, result.check_out):
            raise ConflictError("These dates are no longer available.", code="dates_unavailable")
    elif kind == InventoryKind.ROOM_POOL:
        inventory.reserve_rooms(result.room_type, result.check_in, result.check_out, result.units, kind="booked")
    elif kind == InventoryKind.SLOT:
        inventory.slot_reserve(result.experience_slot, result.units, kind="booked")
    elif kind == InventoryKind.DEPARTURE:
        trips.departure_reserve(result.trip_departure, result.units, kind="booked")


def _release(booking: Booking) -> None:
    """
    Give the stock of a booking back (decline, expiry, cancellation).

    A single unit has nothing to release: its dates are free again as soon
    as the status is no longer blocking.
    """
    kind = booking.inventory_kind
    if kind == InventoryKind.ROOM_POOL:
        inventory.release_rooms(booking.room_type, booking.check_in, booking.check_out, booking.units, kind="booked")
    elif kind == InventoryKind.SLOT:
        inventory.slot_release(booking.experience_slot, booking.units, kind="booked")
    elif kind == InventoryKind.DEPARTURE:
        trips.departure_release(booking.trip_departure, booking.units, kind="booked")


# ---------------------------------------------------------------------------
# Creation
# ---------------------------------------------------------------------------
def _parse_quote_id(quote_id) -> uuid.UUID:
    """A malformed quote id looks like a missing quote (404)."""
    try:
        return uuid.UUID(str(quote_id))
    except (TypeError, ValueError) as exc:
        raise NotFoundError("Quote not found.") from exc


@transaction.atomic
def create_booking(*, guest, quote_id) -> Booking:
    """
    Turn a quote into a booking (BR-BKG-01 to BR-BKG-07).

    Steps: the guest has a verified phone (DEC-012, ``phone_not_verified``);
    the quote is theirs or anonymous and not expired (``quote_expired``),
    never used before (``quote_already_used``); the price is computed again
    and must be the same (``price_changed``, BR-PRC-01); the guest is not the
    host (``own_listing``); the stock is taken (``dates_unavailable``); then
    instant or request is decided (BR-BKG-01/02), the commission rate frozen
    (BR-PAY-06) and, when confirmed, the commission posted (BR-PAY-04).
    Idempotency (BR-SYS-01) is handled by the view.
    """
    if not guest.phone_verified:
        raise ForbiddenError("Verify your phone number first.", code="phone_not_verified")
    _check_guest_limits(guest)
    # Lock the quote: two clicks on the same quote are served one after the other.
    quote = Quote.objects.select_for_update().filter(id=_parse_quote_id(quote_id)).first()
    if quote is None or (quote.guest_id and quote.guest_id != guest.id):
        raise NotFoundError("Quote not found.")
    if quote.is_expired:
        raise ConflictError("This price has expired. Ask for a new one.", code="quote_expired")
    if Booking.objects.filter(quote=quote).exists():
        raise ConflictError("This quote was already booked.", code="quote_already_used")

    result = pricing.reprice(quote)  # re-checks dates, capacity and that the listing is still public
    if result.total_minor != quote.total_minor:
        raise ConflictError("The price changed. Check the new price.", code="price_changed")

    target = result.trip_departure.trip if result.trip_departure else result.listing
    host_account = target.host_account
    if _is_own_offer(guest, host_account):
        raise ForbiddenError("You cannot book your own offer.", code="own_listing")

    kind = quote.inventory_kind
    # Review R7: lock the host wallet before the stock, so two bookings of
    # this host read the deposit one after the other.
    ledger.lock_wallet(host_account)
    _reserve(kind, result)

    # BR-BKG-01/02: instant only when the mode says so, the deposit is above
    # its floor (BR-PAY-10) and the host owes no overdue refund (review R8).
    instant = (
        pricing.effective_approval_mode(target) == ApprovalMode.INSTANT
        and ledger.can_accept_bookings(host_account)
        and not has_overdue_refund(host_account)
    )
    rate_bp = config.commission_rate_bp(host_account)
    snapshot, windows = _snapshot(result)
    now = timezone.now()
    booking = Booking(
        reference=_new_reference(), guest=guest, host_account=host_account, inventory_kind=kind,
        listing=result.listing, room_type=result.room_type, experience_slot=result.experience_slot,
        trip_departure=result.trip_departure, check_in=result.check_in, check_out=result.check_out,
        guests=result.guests, units=result.units,
        status=BookingStatus.CONFIRMED if instant else BookingStatus.PENDING,
        approval_mode_applied=ApprovalMode.INSTANT if instant else ApprovalMode.REQUEST,
        confirmed_at=now if instant else None,
        currency=result.currency, subtotal_minor=result.subtotal_minor, discount_minor=result.discount_minor,
        cleaning_fee_minor=result.cleaning_fee_minor, taxes_minor=result.taxes_minor, total_minor=result.total_minor,
        commission_base_minor=result.commission_base_minor, commission_rate_bp=rate_bp,
        commission_minor=apply_bp(result.commission_base_minor, rate_bp),  # BR-PAY-04, DEC-002
        price_lines=result.lines, cancellation_windows=windows, listing_snapshot=snapshot, quote=quote,
        check_in_code=_new_check_in_code() if instant else "",
    )
    if not instant:
        # BR-BKG-04, DEC-008: the host has request_ttl_hours, or until check-in time if that is sooner.
        ttl = timedelta(hours=int(config.get_value("request_ttl_hours")))
        booking.request_expires_at = min(now + ttl, check_in_at(booking))
    booking.save()
    _record_event(booking, "", actor=guest, role=ActorRole.GUEST)
    _announce_room_change(booking)
    if instant:
        ledger.post_commission(host_account=host_account, booking_id=booking.id,
                               amount_minor=booking.commission_minor, reference=booking.reference)
    return booking


# ---------------------------------------------------------------------------
# Host answers (BR-BKG-03)
# ---------------------------------------------------------------------------
@transaction.atomic
def accept_booking(*, ctx, booking_key, actor) -> Booking:
    """
    The host accepts a request (BR-BKG-03): needs ``bookings.respond``, the
    booking must be pending and not past its deadline (``request_expired``),
    the deposit must be above the credit floor (``deposit_below_floor``,
    BR-PAY-10) and no refund may be overdue (``refund_overdue``, review R8).
    The commission is posted now (BR-PAY-04) and the check-in code created.
    """
    ctx.require("bookings.respond")
    booking = _lock(selectors.get_host_booking(ctx.host_account, booking_key))
    if booking.status != BookingStatus.PENDING:
        raise ConflictError("Only a pending request can be accepted.", code="booking_not_pending")
    if booking.request_expires_at and booking.request_expires_at <= timezone.now():
        raise ConflictError("This request has expired.", code="request_expired")
    if not ledger.can_accept_bookings(ctx.host_account):
        raise DomainError("Top up your deposit before accepting new bookings.", code="deposit_below_floor",
                          status_code=409)
    if has_overdue_refund(ctx.host_account):
        raise DomainError("Pay back the overdue guest refund before accepting new bookings.",
                          code="refund_overdue", status_code=409)
    booking.check_in_code = _new_check_in_code()
    _transition(booking, BookingStatus.CONFIRMED, actor=actor, role=ActorRole.HOST, fields=("check_in_code",))
    ledger.post_commission(host_account=booking.host_account, booking_id=booking.id,
                           amount_minor=booking.commission_minor, reference=booking.reference)
    return booking


@transaction.atomic
def decline_booking(*, ctx, booking_key, actor, reason: str) -> Booking:
    """
    The host declines a request with a reason (BR-BKG-03). The dates or
    seats are freed at once; no money moves (BR-PAY-05).
    """
    ctx.require("bookings.respond")
    reason = _clean_reason(reason)
    booking = _lock(selectors.get_host_booking(ctx.host_account, booking_key))
    if booking.status != BookingStatus.PENDING:
        raise ConflictError("Only a pending request can be declined.", code="booking_not_pending")
    _release(booking)
    booking.decline_reason = reason
    _transition(booking, BookingStatus.DECLINED, actor=actor, role=ActorRole.HOST, note=reason,
                fields=("decline_reason",))
    _announce_room_change(booking)
    return booking


# ---------------------------------------------------------------------------
# Cancellations (section 8)
# ---------------------------------------------------------------------------
def refund_bp_for(windows: list[dict], days_before: int) -> int:
    """
    Refund rate of a policy for a cancellation ``days_before`` days before check-in (BR-CAN-01).

    The most generous window whose ``min_days_before`` is reached wins;
    0 when none is (for example on arrival day with the strict policy).
    """
    for window in sorted(windows, key=lambda w: w["min_days_before"], reverse=True):
        if days_before >= window["min_days_before"]:
            return int(window["refund_bp"])
    return 0


def guest_refund_parts(booking: Booking, *, today=None) -> tuple[int, int]:
    """
    ``(refund_minor, refund_of_base_minor)`` when the guest cancels a confirmed booking.

    ``refund_of_base_minor`` = policy rate x accommodation subtotal after
    discount (the commission base); ``refund_minor`` adds the cleaning fee
    and taxes, always given back before check-in, capped at the total.
    """
    today = today or business_today()
    days_before = (booking.check_in - today).days
    rate = refund_bp_for(booking.cancellation_windows, days_before)
    refund_of_base = apply_bp(booking.commission_base_minor, rate)
    refund = refund_of_base + booking.cleaning_fee_minor + booking.taxes_minor
    return min(refund, booking.total_minor), refund_of_base


def guest_refund_minor(booking: Booking, *, today=None) -> int:
    """
    What the host owes the guest when the guest cancels a confirmed booking (BR-CAN-01, BR-CAN-02).

    Policy rate (from the windows copied at creation) x accommodation
    subtotal after discount, plus the cleaning fee and taxes, which are
    always given back before check-in. "Days before" are calendar days in
    Algeria. Never more than the total.
    """
    return guest_refund_parts(booking, today=today)[0]


def refund_of_base_for(booking: Booking, refund_minor: int) -> int:
    """
    Part of a refund that comes from the commission base (admin cancellations).

    The cleaning fee and taxes are refunded first; what is left of the
    refund comes from the accommodation subtotal, at most the whole base.
    """
    rest = refund_minor - booking.cleaning_fee_minor - booking.taxes_minor
    return max(0, min(rest, booking.commission_base_minor))


def commission_to_return(booking: Booking, refund_of_base_minor: int) -> int:
    """Commission share given back to the host: it follows the refund (DEC-018 revised 2026-11-13)."""
    return ledger.commission_share_to_return(
        commission_minor=booking.commission_minor, commission_base_minor=booking.commission_base_minor,
        refund_of_base_minor=refund_of_base_minor,
    )


def _cancel(booking: Booking, *, actor, role: str, reason: str, refund_minor: int,
            commission_back_minor: int | None = 0) -> Booking:
    """
    Shared end of every cancellation (section 8).

    Frees the stock, records who cancelled and the refund owed, gives back
    ``commission_back_minor`` of the commission if the booking was confirmed
    (``None`` = all of it; DEC-018 revised), opens the refund debt with its
    deadline and ledger memo lines (review R8), and queues the hotel push.
    The caller holds the wallet and booking locks (:func:`_lock`).
    """
    was_confirmed = booking.status == BookingStatus.CONFIRMED
    _release(booking)
    booking.refund_due_minor = refund_minor
    booking.cancelled_by_role = role
    booking.cancel_reason = reason
    _transition(booking, BookingStatus.CANCELLED, actor=actor, role=role, note=reason,
                fields=("refund_due_minor", "cancelled_by_role", "cancel_reason"))
    if was_confirmed and commission_back_minor != 0:
        ledger.reverse_commission(host_account=booking.host_account, booking_id=booking.id,
                                  amount_minor=commission_back_minor, reference=booking.reference)
    if refund_minor > 0:
        days = int(config.get_value("refund_due_days"))
        RefundObligation.objects.create(
            booking=booking, host_account=booking.host_account, guest=booking.guest, amount_minor=refund_minor,
            currency=booking.currency, due_at=booking.cancelled_at + timedelta(days=days),
        )
        ledger.record_refund_due(host_account=booking.host_account, booking_id=booking.id,
                                 amount_minor=refund_minor, reference=booking.reference)
    _announce_room_change(booking)
    return booking


@transaction.atomic
def cancel_by_guest(*, guest, booking_key, reason: str = "") -> Booking:
    """
    The guest cancels their booking (BR-CAN-01, BR-CAN-02).

    Pending: withdrawn, nothing owed. Confirmed: refund by the policy windows,
    and only until check-in time on arrival day (``too_late_to_cancel``;
    support can still cancel). The host gets back the same share of the
    commission as the share of the subtotal refunded (DEC-018 revised).
    Other states: ``booking_not_cancellable``.
    """
    booking = _lock(selectors.get_guest_booking(guest, booking_key))
    reason = (reason or "").strip()
    if booking.status == BookingStatus.PENDING:
        return _cancel(booking, actor=guest, role=ActorRole.GUEST, reason=reason, refund_minor=0)
    if booking.status != BookingStatus.CONFIRMED:
        raise ConflictError("This booking can no longer be cancelled.", code="booking_not_cancellable")
    if timezone.now() >= check_in_at(booking):
        raise DomainError("Contact support to cancel after check-in time.", code="too_late_to_cancel", status_code=409)
    refund, refund_of_base = guest_refund_parts(booking)
    return _cancel(booking, actor=guest, role=ActorRole.GUEST, reason=reason, refund_minor=refund,
                   commission_back_minor=commission_to_return(booking, refund_of_base))


@transaction.atomic
def cancel_by_host(*, ctx, booking_key, actor, reason: str) -> Booking:
    """
    The host cancels a confirmed booking (BR-CAN-03): needs ``bookings.cancel``
    and a reason; the guest is owed the full total and the host gets the
    full commission back (DEC-018 revised). A pending request is declined instead.
    Audited, because it moves money and feeds the host cancellation count.
    """
    ctx.require("bookings.cancel")
    reason = _clean_reason(reason)
    booking = _lock(selectors.get_host_booking(ctx.host_account, booking_key))
    if booking.status != BookingStatus.CONFIRMED:
        raise ConflictError("Only a confirmed booking can be cancelled; decline a request instead.",
                            code="booking_not_cancellable")
    _cancel(booking, actor=actor, role=ActorRole.HOST, reason=reason, refund_minor=booking.total_minor,
            commission_back_minor=None)
    audit.record(actor=actor, action="BOOKING_CANCEL_BY_HOST", obj=booking, note=reason,
                 before={"status": BookingStatus.CONFIRMED},
                 after={"status": booking.status, "refund_due_minor": booking.refund_due_minor})
    return booking


@transaction.atomic
def cancel_by_admin(*, actor, booking_key, reason: str, refund_due_minor: int | None = None) -> Booking:
    """
    A BLADUS admin cancels a pending or confirmed booking (section 8, BR-CAN-04).

    Reason required. ``refund_due_minor`` between 0 and the total; when not
    given: the full total for a confirmed booking, 0 for a pending one
    (nothing was paid yet). The commission follows the refund: the share of
    the subtotal refunded decides the share given back (DEC-018 revised).
    Audited (BR-STF-02).
    """
    reason = _clean_reason(reason)
    booking = _lock(selectors.get_admin_booking(booking_key))
    if not booking.is_active:
        raise ConflictError("This booking can no longer be cancelled.", code="booking_not_cancellable")
    if refund_due_minor is None:
        refund_due_minor = booking.total_minor if booking.status == BookingStatus.CONFIRMED else 0
    if not 0 <= refund_due_minor <= booking.total_minor:
        raise DomainError("The refund must be between 0 and the booking total.", code="invalid_refund",
                          errors={"refund_due_minor": [f"Between 0 and {booking.total_minor}."]})
    before = booking.status
    _cancel(booking, actor=actor, role=ActorRole.ADMIN, reason=reason, refund_minor=refund_due_minor,
            commission_back_minor=commission_to_return(booking, refund_of_base_for(booking, refund_due_minor)))
    audit.record(actor=actor, action="BOOKING_CANCEL_BY_ADMIN", obj=booking, note=reason,
                 before={"status": before}, after={"status": booking.status, "refund_due_minor": refund_due_minor})
    return booking


# ---------------------------------------------------------------------------
# Scheduled jobs (BR-BKG-04, BR-BKG-05)
# ---------------------------------------------------------------------------
def expire_pending_requests(now: datetime | None = None) -> int:
    """
    Expire every request whose deadline has passed and free its stock (BR-BKG-04).

    No money moves (BR-PAY-05). Each booking is handled in its own
    transaction under a lock, so a host accepting at the same moment wins
    or loses cleanly. Returns how many bookings expired. Run every 5 minutes
    (management command ``expire_requests``).
    """
    now = now or timezone.now()
    ids = list(Booking.objects.filter(status=BookingStatus.PENDING, request_expires_at__lte=now)
               .values_list("id", flat=True))
    count = 0
    for booking_id in ids:
        with transaction.atomic():
            booking = Booking.objects.select_for_update().get(pk=booking_id)
            # Re-check under the lock: the host may have answered in between.
            if booking.status != BookingStatus.PENDING or booking.request_expires_at > now:
                continue
            _release(booking)
            _transition(booking, BookingStatus.EXPIRED, actor=None, role=ActorRole.SYSTEM)
            _announce_room_change(booking)
            count += 1
    return count


def complete_finished_stays(now: datetime | None = None) -> int:
    """
    Mark confirmed bookings completed once check-out time + 2 hours has
    passed in Algeria (BR-BKG-05, DEC-010). Returns how many were completed.
    Run every 5 minutes (management command ``complete_stays``).
    """
    now = now or timezone.now()
    local_today = now.astimezone(business_tz()).date()
    # Cheap first filter on the date; the exact time is checked per booking.
    candidates = Booking.objects.filter(status=BookingStatus.CONFIRMED, check_out__lte=local_today)
    count = 0
    for candidate in candidates:
        if check_out_at(candidate) + COMPLETION_DELAY > now:
            continue
        with transaction.atomic():
            booking = Booking.objects.select_for_update().get(pk=candidate.pk)
            if booking.status != BookingStatus.CONFIRMED:
                continue
            _transition(booking, BookingStatus.COMPLETED, actor=None, role=ActorRole.SYSTEM)
            count += 1
    return count


# ---------------------------------------------------------------------------
# Stay confirmation (review R13)
# ---------------------------------------------------------------------------
STAY_CONFIRMABLE = (BookingStatus.CONFIRMED, BookingStatus.COMPLETED)


def _mark_stay(booking: Booking, via: str) -> Booking:
    """Record the first proof that the stay happened; later proofs change nothing."""
    if booking.stay_confirmed_at is None:
        booking.stay_confirmed_at, booking.stay_confirmed_via = timezone.now(), via
        booking.save(update_fields=["stay_confirmed_at", "stay_confirmed_via", "updated_at"])
    return booking


@transaction.atomic
def confirm_stay_by_host(*, ctx, booking_key, code: str) -> Booking:
    """
    The host enters the guest's check-in code on arrival (review R13).

    Needs ``bookings.respond``; the booking must be confirmed or completed,
    its check-in day reached, and the code right (``invalid_code``). The
    stay then counts as proven, which a review needs.
    """
    ctx.require("bookings.respond")
    booking = Booking.objects.select_for_update().get(pk=selectors.get_host_booking(ctx.host_account, booking_key).pk)
    if booking.status not in STAY_CONFIRMABLE:
        raise ConflictError("Only a confirmed stay can be confirmed.", code="booking_not_confirmed")
    if business_today() < booking.check_in:
        raise ConflictError("The stay has not started yet.", code="stay_not_started")
    if not booking.check_in_code or not secrets.compare_digest(booking.check_in_code, (code or "").strip()):
        raise DomainError("This code is not right.", code="invalid_code", errors={"code": ["Wrong code."]})
    return _mark_stay(booking, StayConfirmedVia.HOST_CODE)


@transaction.atomic
def confirm_stay_by_guest(*, guest, booking_key) -> Booking:
    """
    The guest confirms the stay took place, from check-in time on (review R13).

    Only for a confirmed or completed booking (``booking_not_confirmed``),
    not before check-in time (``stay_not_started``).
    """
    booking = Booking.objects.select_for_update().get(pk=selectors.get_guest_booking(guest, booking_key).pk)
    if booking.status not in STAY_CONFIRMABLE:
        raise ConflictError("Only a confirmed stay can be confirmed.", code="booking_not_confirmed")
    if timezone.now() < check_in_at(booking):
        raise ConflictError("The stay has not started yet.", code="stay_not_started")
    return _mark_stay(booking, StayConfirmedVia.GUEST)


# ---------------------------------------------------------------------------
# Refund debts (review R8)
# ---------------------------------------------------------------------------
def _lock_refund(queryset, refund_id) -> RefundObligation:
    """Read one refund debt of ``queryset`` under a lock, or 404."""
    try:
        refund_uuid = uuid.UUID(str(refund_id))
    except (TypeError, ValueError) as exc:
        raise NotFoundError("Refund not found.") from exc
    refund = queryset.select_for_update().filter(pk=refund_uuid).first()
    if refund is None:
        raise NotFoundError("Refund not found.")
    return refund


@transaction.atomic
def declare_refund_paid(*, ctx, refund_id, actor, payment_reference: str) -> RefundObligation:
    """
    The host says the refund was sent, with a transfer reference (review R8).

    Needs ``bookings.cancel`` (the people who handle money with guests).
    The debt is settled only when the guest confirms or an admin checks the
    proof; while declared it does not count as overdue.
    """
    ctx.require("bookings.cancel")
    reference = (payment_reference or "").strip()
    if not reference:
        raise DomainError("Give the transfer reference.", code="reference_required",
                          errors={"payment_reference": ["Required."]})
    refund = _lock_refund(RefundObligation.objects.filter(host_account=ctx.host_account), refund_id)
    if refund.status not in (RefundStatus.OPEN, RefundStatus.DISPUTED):
        raise ConflictError("This refund is not waiting for payment.", code="refund_not_open")
    refund.status, refund.declared_at, refund.payment_reference = RefundStatus.DECLARED, timezone.now(), reference[:200]
    refund.save(update_fields=["status", "declared_at", "payment_reference"])
    audit.record(actor=actor, action="REFUND_DECLARED_PAID", obj=refund, after={"amount_minor": refund.amount_minor})
    return refund


def _settle(refund: RefundObligation, *, actor, note: str = "") -> RefundObligation:
    """Close a refund debt and write the ledger memo line that cancels it."""
    refund.status, refund.settled_at, refund.settled_by = RefundStatus.SETTLED, timezone.now(), actor
    refund.note = note or refund.note
    refund.save(update_fields=["status", "settled_at", "settled_by", "note"])
    ledger.record_refund_settled(host_account=refund.host_account, booking_id=refund.booking_id,
                                 reference=refund.booking.reference, actor=actor)
    return refund


@transaction.atomic
def confirm_refund_received(*, guest, refund_id) -> RefundObligation:
    """The guest confirms the money arrived: the debt is settled (review R8)."""
    refund = _lock_refund(RefundObligation.objects.filter(guest=guest), refund_id)
    if refund.status == RefundStatus.SETTLED:
        return refund
    return _settle(refund, actor=guest)


@transaction.atomic
def dispute_refund(*, guest, refund_id, note: str) -> RefundObligation:
    """
    The guest says a declared refund never arrived (review R8).

    The debt goes back to unpaid (``disputed``); if its deadline has passed
    the host is blocked again until it is settled.
    """
    note = (note or "").strip()
    if not note:
        raise DomainError("Say what is wrong.", code="reason_required", errors={"note": ["Required."]})
    refund = _lock_refund(RefundObligation.objects.filter(guest=guest), refund_id)
    if refund.status != RefundStatus.DECLARED:
        raise ConflictError("Only a refund the host declared paid can be disputed.", code="refund_not_declared")
    refund.status, refund.note = RefundStatus.DISPUTED, note[:2000]
    refund.save(update_fields=["status", "note"])
    return refund


@transaction.atomic
def admin_settle_refund(*, actor, refund_id, note: str) -> RefundObligation:
    """An admin closes a refund debt after checking the proof (review R8). Note required, audited."""
    note = (note or "").strip()
    if not note:
        raise DomainError("Say which proof was checked.", code="reason_required", errors={"note": ["Required."]})
    refund = _lock_refund(RefundObligation.objects.all(), refund_id)
    if refund.status == RefundStatus.SETTLED:
        raise ConflictError("This refund is already settled.", code="refund_settled")
    before = refund.status
    _settle(refund, actor=actor, note=note[:2000])
    audit.record(actor=actor, action="REFUND_SETTLE_BY_ADMIN", obj=refund, note=note,
                 before={"status": before}, after={"status": refund.status})
    return refund
