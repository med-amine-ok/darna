"""
HTTP endpoints of the bookings app (thin layer: rules live in ``services.py``).

- Guest: ``/me/bookings`` (create with an ``Idempotency-Key``, list, detail, cancel);
- Host: ``/host/bookings`` scoped to the active workspace (list, detail,
  accept, decline, cancel); another host's booking answers 404;
- Admin: ``/admin/bookings`` (list, detail, cancel), ``IsAdmin`` only.
"""

import json

from django.core.serializers.json import DjangoJSONEncoder
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import IsAdmin, IsPhoneVerified
from apps.core import idempotency
from apps.core.errors import ForbiddenError
from apps.hosts.context import IsHost, get_host_context

from . import selectors, services
from .models import UNPAID_REFUND_STATUSES, Booking, RefundObligation
from .serializers import (
    AdminBookingSerializer,
    AdminCancelSerializer,
    BookingCreateSerializer,
    GuestBookingSerializer,
    HostBookingSerializer,
    ReasonSerializer,
    RefundDeclareSerializer,
    RefundNoteSerializer,
    RefundObligationSerializer,
    StayCodeSerializer,
)

# Logical name of booking creation in the idempotency table (BR-SYS-01).
CREATE_ENDPOINT = "bookings.create"


# ---------------------------------------------------------------------------
# Guest
# ---------------------------------------------------------------------------
class GuestBookingListCreateView(generics.ListAPIView):
    """
    ``GET /me/bookings`` (filter ``status``, paginated) and ``POST /me/bookings``.

    Creating needs a verified phone (DEC-012) and should carry an
    ``Idempotency-Key`` header: a retry with the same key returns the first
    answer and never books twice (BR-SYS-01).
    """

    serializer_class = GuestBookingSerializer
    throttle_scope = "booking"

    def get_permissions(self):
        """Any signed-in user may list; creating also needs a verified phone (DEC-012)."""
        if self.request.method == "POST":
            return [IsAuthenticated(), IsPhoneVerified()]
        return [IsAuthenticated()]

    def permission_denied(self, request, message=None, code=None):
        """Answer ``phone_not_verified`` (instead of a generic 403) when only the phone check failed."""
        if request.user and request.user.is_authenticated and not request.user.phone_verified:
            raise ForbiddenError("Verify your phone number first.", code="phone_not_verified")
        super().permission_denied(request, message=message, code=code)

    def get_queryset(self):
        """Only the caller's own bookings."""
        if getattr(self, "swagger_fake_view", False):  # schema generation runs without a user
            return Booking.objects.none()
        return selectors.guest_bookings(self.request.user, status=self.request.query_params.get("status"))

    def post(self, request):
        """Create a booking from a quote, once per ``Idempotency-Key``."""
        data = BookingCreateSerializer(data=request.data)
        data.is_valid(raise_exception=True)
        key = request.headers.get("Idempotency-Key")
        payload = {"quote_id": str(data.validated_data["quote_id"])}
        stored = idempotency.lookup(request.user, CREATE_ENDPOINT, key, payload)
        if stored:
            return Response(stored.response_body, status=stored.response_code)
        booking = services.create_booking(guest=request.user, quote_id=data.validated_data["quote_id"])
        # Plain JSON types (UUIDs, dates as text) so the answer can be stored for retries.
        body = json.loads(json.dumps(GuestBookingSerializer(booking).data, cls=DjangoJSONEncoder))
        idempotency.remember(request.user, CREATE_ENDPOINT, key, payload, status.HTTP_201_CREATED, body)
        return Response(body, status=status.HTTP_201_CREATED)


class GuestBookingDetailView(APIView):
    """``GET /me/bookings/{id_or_reference}``: one of the caller's bookings (address only once confirmed, BR-SRC-03)."""

    serializer_class = GuestBookingSerializer  # response shape, for the OpenAPI schema

    def get(self, request, key):
        """Return the booking, or 404 when it is not the caller's."""
        return Response(GuestBookingSerializer(selectors.get_guest_booking(request.user, key)).data)


class GuestBookingCancelView(APIView):
    """``POST /me/bookings/{id}/cancel``: the guest cancels (BR-CAN-01, BR-CAN-02)."""

    serializer_class = GuestBookingSerializer  # response shape, for the OpenAPI schema

    def post(self, request, key):
        """Cancel and return the booking with the refund the host owes."""
        data = ReasonSerializer(data=request.data)
        data.is_valid(raise_exception=True)
        booking = services.cancel_by_guest(guest=request.user, booking_key=key, reason=data.validated_data["reason"])
        return Response(GuestBookingSerializer(booking).data)


# ---------------------------------------------------------------------------
# Host
# ---------------------------------------------------------------------------
class HostBookingListView(generics.ListAPIView):
    """``GET /host/bookings``: bookings of the active workspace (filters ``status``, ``listing``; needs ``bookings.view``)."""

    permission_classes = [IsHost]
    serializer_class = HostBookingSerializer

    def get_queryset(self):
        """Always scoped to ``ctx.host_account`` (OWASP API1)."""
        if getattr(self, "swagger_fake_view", False):  # schema generation runs without a user
            return Booking.objects.none()
        ctx = get_host_context(self.request)
        ctx.require("bookings.view")
        params = self.request.query_params
        return selectors.host_bookings(ctx.host_account, status=params.get("status"), listing=params.get("listing"))


class HostBookingDetailView(APIView):
    """``GET /host/bookings/{id}``: one booking of the active workspace, else 404."""

    serializer_class = HostBookingSerializer  # response shape, for the OpenAPI schema
    permission_classes = [IsHost]

    def get(self, request, key):
        """Return the booking as the host sees it."""
        ctx = get_host_context(request)
        ctx.require("bookings.view")
        return Response(HostBookingSerializer(selectors.get_host_booking(ctx.host_account, key)).data)


class HostBookingAcceptView(APIView):
    """``POST /host/bookings/{id}/accept``: confirm a request (BR-BKG-03, BR-PAY-10)."""

    serializer_class = HostBookingSerializer  # response shape, for the OpenAPI schema
    permission_classes = [IsHost]

    def post(self, request, key):
        """Accept and return the confirmed booking."""
        booking = services.accept_booking(ctx=get_host_context(request), booking_key=key, actor=request.user)
        return Response(HostBookingSerializer(booking).data)


class HostBookingDeclineView(APIView):
    """``POST /host/bookings/{id}/decline`` with ``{"reason"}``: refuse a request (BR-BKG-03)."""

    serializer_class = HostBookingSerializer  # response shape, for the OpenAPI schema
    permission_classes = [IsHost]

    def post(self, request, key):
        """Decline and return the booking; the dates are free again."""
        data = ReasonSerializer(data=request.data)
        data.is_valid(raise_exception=True)
        booking = services.decline_booking(ctx=get_host_context(request), booking_key=key, actor=request.user,
                                           reason=data.validated_data["reason"])
        return Response(HostBookingSerializer(booking).data)


class HostBookingCancelView(APIView):
    """``POST /host/bookings/{id}/cancel`` with ``{"reason"}``: cancel a confirmed booking (BR-CAN-03)."""

    serializer_class = HostBookingSerializer  # response shape, for the OpenAPI schema
    permission_classes = [IsHost]

    def post(self, request, key):
        """Cancel; the guest is owed the full total and the commission comes back (DEC-018)."""
        data = ReasonSerializer(data=request.data)
        data.is_valid(raise_exception=True)
        booking = services.cancel_by_host(ctx=get_host_context(request), booking_key=key, actor=request.user,
                                          reason=data.validated_data["reason"])
        return Response(HostBookingSerializer(booking).data)


# ---------------------------------------------------------------------------
# Admin
# ---------------------------------------------------------------------------
class AdminBookingListView(generics.ListAPIView):
    """``GET /admin/bookings``: every booking (filters ``status``, ``host``, ``listing``, ``guest``, ``reference``)."""

    permission_classes = [IsAdmin]
    serializer_class = AdminBookingSerializer

    def get_queryset(self):
        """Apply the query filters."""
        params = self.request.query_params
        return selectors.admin_bookings(
            status=params.get("status"), host=params.get("host"), listing=params.get("listing"),
            guest=params.get("guest"), reference=params.get("reference"),
        ).prefetch_related("events")


class AdminBookingDetailView(APIView):
    """``GET /admin/bookings/{id}``: any booking, with its history."""

    serializer_class = AdminBookingSerializer  # response shape, for the OpenAPI schema
    permission_classes = [IsAdmin]

    def get(self, request, key):
        """Return the booking as support sees it."""
        return Response(AdminBookingSerializer(selectors.get_admin_booking(key)).data)


class AdminBookingCancelView(APIView):
    """``POST /admin/bookings/{id}/cancel`` with ``{"reason", "refund_due_minor"?}`` (section 8, audited)."""

    serializer_class = AdminBookingSerializer  # response shape, for the OpenAPI schema
    permission_classes = [IsAdmin]

    def post(self, request, key):
        """Cancel any pending or confirmed booking."""
        data = AdminCancelSerializer(data=request.data)
        data.is_valid(raise_exception=True)
        booking = services.cancel_by_admin(actor=request.user, booking_key=key, reason=data.validated_data["reason"],
                                           refund_due_minor=data.validated_data.get("refund_due_minor"))
        return Response(AdminBookingSerializer(booking).data)


# ---------------------------------------------------------------------------
# Stay confirmation (review R13)
# ---------------------------------------------------------------------------
class GuestConfirmStayView(APIView):
    """``POST /me/bookings/{key}/confirm-stay``: the guest confirms the stay took place (from check-in time)."""

    serializer_class = GuestBookingSerializer  # response shape, for the OpenAPI schema

    def post(self, request, key):
        """Mark the stay as confirmed and return the booking."""
        booking = services.confirm_stay_by_guest(guest=request.user, booking_key=key)
        return Response(GuestBookingSerializer(booking).data)


class HostConfirmStayView(APIView):
    """``POST /host/bookings/{key}/confirm-stay``: the host enters the guest's check-in code on arrival."""

    serializer_class = StayCodeSerializer
    permission_classes = [IsHost]

    def post(self, request, key):
        """Check the code and return the booking."""
        data = StayCodeSerializer(data=request.data)
        data.is_valid(raise_exception=True)
        booking = services.confirm_stay_by_host(ctx=get_host_context(request), booking_key=key,
                                                code=data.validated_data["code"])
        return Response(HostBookingSerializer(booking).data)


# ---------------------------------------------------------------------------
# Refund debts (review R8)
# ---------------------------------------------------------------------------
class GuestRefundListView(generics.ListAPIView):
    """``GET /me/refunds``: refunds hosts owe me, newest deadline last."""

    serializer_class = RefundObligationSerializer

    def get_queryset(self):
        """Only the signed-in guest's refunds."""
        return RefundObligation.objects.filter(guest=self.request.user).select_related("booking")


class GuestRefundConfirmView(APIView):
    """``POST /me/refunds/{id}/confirm-received``: the money arrived, the debt is settled."""

    serializer_class = RefundObligationSerializer

    def post(self, request, pk):
        """Settle and return the refund."""
        return Response(RefundObligationSerializer(services.confirm_refund_received(guest=request.user, refund_id=pk)).data)


class GuestRefundDisputeView(APIView):
    """``POST /me/refunds/{id}/dispute``: the host declared it paid but nothing arrived."""

    serializer_class = RefundNoteSerializer

    def post(self, request, pk):
        """Put the refund back to unpaid with the guest's note."""
        data = RefundNoteSerializer(data=request.data)
        data.is_valid(raise_exception=True)
        refund = services.dispute_refund(guest=request.user, refund_id=pk, note=data.validated_data["note"])
        return Response(RefundObligationSerializer(refund).data)


class HostRefundListView(generics.ListAPIView):
    """``GET /host/refunds``: refunds the active workspace owes guests (filter ``status``)."""

    permission_classes = [IsHost]
    serializer_class = RefundObligationSerializer

    def get_queryset(self):
        """Only the active workspace's refunds."""
        ctx = get_host_context(self.request)
        qs = RefundObligation.objects.filter(host_account=ctx.host_account).select_related("booking")
        if status_filter := self.request.query_params.get("status"):
            qs = qs.filter(status=status_filter)
        return qs


class HostRefundDeclareView(APIView):
    """``POST /host/refunds/{id}/declare-paid``: the host says the refund was sent (needs ``bookings.cancel``)."""

    permission_classes = [IsHost]
    serializer_class = RefundDeclareSerializer

    def post(self, request, pk):
        """Record the transfer reference; the guest or an admin then settles it."""
        data = RefundDeclareSerializer(data=request.data)
        data.is_valid(raise_exception=True)
        refund = services.declare_refund_paid(ctx=get_host_context(request), refund_id=pk, actor=request.user,
                                              payment_reference=data.validated_data["payment_reference"])
        return Response(RefundObligationSerializer(refund).data)


class AdminRefundListView(generics.ListAPIView):
    """``GET /admin/refunds`` (filters ``status``, ``host_account``, ``overdue=true``)."""

    permission_classes = [IsAdmin]
    serializer_class = RefundObligationSerializer

    def get_queryset(self):
        """Every refund debt, filtered."""
        from django.utils import timezone

        params = self.request.query_params
        qs = RefundObligation.objects.select_related("booking")
        if status_filter := params.get("status"):
            qs = qs.filter(status=status_filter)
        if host := params.get("host_account"):
            qs = qs.filter(host_account_id=host)
        if params.get("overdue") in ("1", "true"):
            qs = qs.filter(status__in=UNPAID_REFUND_STATUSES, due_at__lte=timezone.now())
        return qs


class AdminRefundSettleView(APIView):
    """``POST /admin/refunds/{id}/settle``: close a refund debt after checking the proof (audited)."""

    permission_classes = [IsAdmin]
    serializer_class = RefundNoteSerializer

    def post(self, request, pk):
        """Settle with the admin's note."""
        data = RefundNoteSerializer(data=request.data)
        data.is_valid(raise_exception=True)
        refund = services.admin_settle_refund(actor=request.user, refund_id=pk, note=data.validated_data["note"])
        return Response(RefundObligationSerializer(refund).data)
