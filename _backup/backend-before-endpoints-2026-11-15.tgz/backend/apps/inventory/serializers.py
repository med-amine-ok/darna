"""Input and output shapes of the inventory API (host calendar and slots)."""

from rest_framework import serializers

from apps.core.money import money_dict

from apps.core.models import OutboxMessage

from .models import ExperienceSlot, InventoryConflict


class CalendarBlocksSerializer(serializers.Serializer):
    """Body of ``PUT /host/listings/{id}/calendar/blocks``: close or open days."""

    dates = serializers.ListField(child=serializers.DateField(), allow_empty=False, max_length=366)
    blocked = serializers.BooleanField()


class CalendarPricesSerializer(serializers.Serializer):
    """Body of ``PUT /host/listings/{id}/calendar/prices``: special price, or ``null`` to remove it."""

    dates = serializers.ListField(child=serializers.DateField(), allow_empty=False, max_length=366)
    price_minor = serializers.IntegerField(allow_null=True, min_value=1)


class RoomCalendarSerializer(serializers.Serializer):
    """Body of ``PUT /host/room-types/{id}/calendar``: sellable units and/or special price per night."""

    dates = serializers.ListField(child=serializers.DateField(), allow_empty=False, max_length=366)
    total = serializers.IntegerField(required=False, min_value=0)
    price_minor = serializers.IntegerField(required=False, allow_null=True, min_value=1)


class SlotWriteSerializer(serializers.Serializer):
    """Body to create or change an experience slot."""

    starts_at = serializers.DateTimeField()
    ends_at = serializers.DateTimeField()
    seats_total = serializers.IntegerField(min_value=1, max_value=1000)
    price_override_minor = serializers.IntegerField(required=False, allow_null=True, min_value=1)


class HostSlotSerializer(serializers.ModelSerializer):
    """A slot as its host sees it, with the held and booked counters."""

    seats_left = serializers.IntegerField(read_only=True)
    price = serializers.SerializerMethodField()

    class Meta:
        """Which model and fields this serializer uses."""

        model = ExperienceSlot
        fields = ("id", "starts_at", "ends_at", "seats_total", "seats_held", "seats_booked", "seats_left",
                  "price", "price_override_minor", "is_cancelled")

    def get_price(self, obj) -> dict:
        """Price per person of the slot."""
        return money_dict(obj.price_minor, obj.listing.currency)


class InventoryConflictSerializer(serializers.ModelSerializer):
    """A night where a hotel system reported fewer rooms than BLADUS already sold (review R3)."""

    room_type_name = serializers.CharField(source="room_type.name", read_only=True)
    listing_id = serializers.UUIDField(source="room_type.listing_id", read_only=True)

    class Meta:
        """Model and fields this serializer reads."""

        model = InventoryConflict
        fields = ["id", "listing_id", "room_type_id", "room_type_name", "night", "external_total", "sold", "source",
                  "status", "resolution_note", "resolved_at", "created_at"]


class ConflictResolveSerializer(serializers.Serializer):
    """Body of ``POST /admin/inventory-conflicts/{id}/resolve``: what the admin did."""

    note = serializers.CharField(max_length=2000)


class OutboxMessageSerializer(serializers.ModelSerializer):
    """An outbox message, for the admin queue of failed deliveries (review R14)."""

    class Meta:
        """Model and fields this serializer reads."""

        model = OutboxMessage
        fields = ["id", "topic", "payload", "status", "attempts", "next_attempt_at", "last_error", "created_at", "sent_at"]
