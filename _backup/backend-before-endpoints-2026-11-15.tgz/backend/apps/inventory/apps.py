"""Django app configuration for ``apps.inventory``."""

from django.apps import AppConfig


class InventoryConfig(AppConfig):
    """Calendar and availability of listings and room types."""

    name = "apps.inventory"
    label = "inventory"
    default_auto_field = "django.db.models.BigAutoField"

    def ready(self) -> None:
        """
        Plug the inventory date filter into the catalog search and the
        hotel push handler into the outbox.

        Catalog is a lower layer and may not import inventory, so inventory
        registers itself here (see ``catalog.selectors.register_date_filter``).
        """
        from apps.catalog.selectors import register_date_filter
        from apps.core.outbox import register_handler

        from .selectors import available_listing_ids
        from .services import push_handler

        register_date_filter(available_listing_ids)
        # Review R3: deliver "inventory.push" outbox messages to hotel systems.
        register_handler("inventory.push", push_handler)
