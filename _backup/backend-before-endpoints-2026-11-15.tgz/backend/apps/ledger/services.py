"""
Ledger services: the only code allowed to move money.

Public functions:
- :func:`wallet_balance_minor` and :func:`wallet_state` : read a host's deposit;
- :func:`lock_wallet` : row lock taken first by every booking write (review R7);
- :func:`create_topup`, :func:`approve_topup`, :func:`reject_topup` : admin top-ups,
  four eyes on the host's 24-hour total (BR-PAY-07, review R6);
- :func:`create_adjustment`, :func:`approve_adjustment`, :func:`reject_adjustment` :
  manual corrections, always two admins (review R6);
- :func:`post_commission` : take the commission when a booking is confirmed;
- :func:`reverse_commission` : give back the share that follows the refund (DEC-018 revised);
- :func:`record_refund_due`, :func:`record_refund_settled` : memo lines of a refund a
  host owes a guest (review R8);
- :func:`reconcile_balances` : nightly check of every stored balance (review R11);
- :func:`can_accept_bookings` : credit floor check (BR-PAY-10).

Lock order (review R7): the host wallet balance row is always locked before
any listing or stock row, so two writers never wait for each other in a
circle. No platform-wide row is updated on the booking path: commission
revenue is the sum of its ledger lines.
"""

from datetime import timedelta

from django.db import IntegrityError, transaction
from django.db.models import Sum
from django.utils import timezone

from apps.audit import services as audit
from apps.config import services as config
from apps.core.errors import ConflictError, DomainError, ForbiddenError

from .models import (
    AccountBalance,
    AccountKind,
    AdjustmentStatus,
    LedgerAccount,
    LedgerEntry,
    LedgerTransaction,
    TopupStatus,
    TransactionKind,
    WalletAdjustment,
    WalletTopup,
)

# Accounts whose balance is kept in AccountBalance (friendly sign: minus the sum of lines).
BALANCED_KINDS = (AccountKind.HOST_WALLET,)


# ---------------------------------------------------------------------------
# Accounts
# ---------------------------------------------------------------------------
def wallet_account(host_account) -> LedgerAccount:
    """Return the deposit wallet of a host account, creating it on first use."""
    account, _ = LedgerAccount.objects.get_or_create(
        host_account=host_account,
        kind=AccountKind.HOST_WALLET,
        defaults={"code": f"host_wallet:{host_account.id}"},
    )
    return account


def platform_account(kind: str, suffix: str = "") -> LedgerAccount:
    """Return a platform account such as ``platform_cash:ccp_transfer`` or ``commission_revenue``."""
    code = f"{kind}:{suffix}" if suffix else kind
    account, _ = LedgerAccount.objects.get_or_create(code=code, defaults={"kind": kind})
    return account


def lock_wallet(host_account) -> AccountBalance:
    """
    Lock the host's deposit balance row for the rest of the transaction (review R7).

    Booking creation and acceptance call this first, before reading the
    floor and before touching any stock, so two bookings of the same host
    are checked one after the other and cannot both pass the credit floor.
    Must run inside ``transaction.atomic``.
    """
    account = wallet_account(host_account)
    AccountBalance.objects.get_or_create(account=account)
    return AccountBalance.objects.select_for_update().get(account=account)


def commission_revenue_minor() -> int:
    """BLADUS commission kept so far, computed from the ledger lines, never from a shared row (review R7)."""
    account = platform_account(AccountKind.COMMISSION_REVENUE)
    total = LedgerEntry.objects.filter(account=account).aggregate(total=Sum("amount_minor"))["total"] or 0
    return -total


def wallet_balance_minor(host_account) -> int:
    """Deposit of a host in centimes (negative when the host owes commission)."""
    balance = AccountBalance.objects.filter(account__host_account=host_account, account__kind=AccountKind.HOST_WALLET).first()
    return balance.balance_minor if balance else 0


def wallet_state(host_account) -> dict:
    """
    Everything the host wallet widget needs: balance, commission rate, credit
    floor and whether new bookings can still be confirmed.
    """
    balance = wallet_balance_minor(host_account)
    limit = config.credit_limit_minor(host_account)
    return {
        "balance_minor": balance,
        "currency": "DZD",
        "commission_rate_bp": config.commission_rate_bp(host_account),
        "credit_limit_minor": limit,
        "is_negative": balance < 0,
        "can_accept_bookings": balance >= -limit,
    }


def can_accept_bookings(host_account) -> bool:
    """
    True while the deposit is above the credit floor (BR-PAY-10).

    Below the floor, instant bookings become requests and the host cannot
    accept requests until the deposit is topped up.
    """
    return wallet_balance_minor(host_account) >= -config.credit_limit_minor(host_account)


# ---------------------------------------------------------------------------
# Posting
# ---------------------------------------------------------------------------
def _post(*, kind: str, description: str, lines: list[tuple[LedgerAccount, int]], wallet_delta: dict | None = None,
          booking_id=None, topup=None, reverses=None, adjustment=None, actor=None) -> LedgerTransaction:
    """
    Write one balanced transaction (BR-PAY-02). Must run inside ``transaction.atomic``.

    ``lines`` is a list of ``(account, amount_minor)``; debits positive,
    credits negative; the sum must be zero. ``wallet_delta`` maps a wallet
    account to the change of its friendly balance (see AccountBalance).
    """
    if sum(amount for _, amount in lines) != 0:
        raise RuntimeError("Ledger transaction is not balanced.")
    tx = LedgerTransaction.objects.create(
        kind=kind, description=description, booking_id=booking_id, topup=topup, reverses=reverses,
        adjustment=adjustment, created_by=actor,
    )
    LedgerEntry.objects.bulk_create([LedgerEntry(transaction=tx, account=account, amount_minor=amount) for account, amount in lines])
    for account, delta in (wallet_delta or {}).items():
        # Lock the balance row so two postings cannot overwrite each other.
        balance, _ = AccountBalance.objects.select_for_update().get_or_create(account=account)
        balance.balance_minor += delta
        balance.save(update_fields=["balance_minor", "updated_at"])
    return tx


# ---------------------------------------------------------------------------
# Top-ups (BR-PAY-07)
# ---------------------------------------------------------------------------
@transaction.atomic
def create_topup(*, host_account, method: str, amount_minor: int, receipt_reference: str, note: str = "", actor) -> WalletTopup:
    """
    Record a deposit the host sent by transfer.

    Small amounts are credited at once. When the host's top-ups of the last
    24 hours plus this one go above the four-eyes threshold, it stays
    ``pending_approval`` until a different admin approves it (review R6).
    Raises ``ConflictError(code="receipt_already_used")`` for a reused receipt.
    """
    if not 100 <= amount_minor <= 1_000_000_000:
        raise DomainError("The amount must be between 1 and 10,000,000 DZD.", code="invalid_amount")
    receipt_reference = receipt_reference.strip()
    if not receipt_reference:
        raise DomainError("The receipt reference is required.", code="receipt_required")
    # Review R6: the threshold applies to the host's rolling 24-hour total, so
    # splitting one large deposit into small ones still needs a second admin.
    # The host row is locked so two admins recording at once are counted together.
    type(host_account).objects.select_for_update().filter(pk=host_account.pk).first()
    recent = WalletTopup.objects.filter(
        host_account=host_account, created_at__gte=timezone.now() - timedelta(hours=24),
        status__in=[TopupStatus.PENDING_APPROVAL, TopupStatus.APPROVED],
    ).aggregate(total=Sum("amount_minor"))["total"] or 0
    needs_second_admin = recent + amount_minor > int(config.get_value("topup_four_eyes_minor"))
    try:
        with transaction.atomic():
            topup = WalletTopup.objects.create(
                host_account=host_account, method=method, amount_minor=amount_minor, receipt_reference=receipt_reference,
                note=note, requested_by=actor,
                status=TopupStatus.PENDING_APPROVAL if needs_second_admin else TopupStatus.APPROVED,
                approved_by=None if needs_second_admin else actor,
                approved_at=None if needs_second_admin else timezone.now(),
            )
    except IntegrityError as exc:
        raise ConflictError("This receipt was already recorded.", code="receipt_already_used") from exc

    if not needs_second_admin:
        _credit_topup(topup, actor)
    audit.record(actor=actor, action="WALLET_TOPUP_CREATE", obj=topup,
                 after={"amount_minor": amount_minor, "method": method, "status": topup.status, "host_account": str(host_account.id)})
    return topup


def _credit_topup(topup: WalletTopup, actor) -> None:
    """Post the ledger lines of an approved top-up: BLADUS cash up, host wallet up."""
    wallet = wallet_account(topup.host_account)
    cash = platform_account(AccountKind.PLATFORM_CASH, topup.method)
    _post(
        kind=TransactionKind.WALLET_TOPUP,
        description=f"Deposit top-up {topup.receipt_reference}",
        lines=[(cash, topup.amount_minor), (wallet, -topup.amount_minor)],
        wallet_delta={wallet: topup.amount_minor},
        topup=topup,
        actor=actor,
    )


@transaction.atomic
def approve_topup(topup_id, *, actor) -> WalletTopup:
    """Second admin approves a large top-up. The approver must not be the admin who recorded it."""
    topup = WalletTopup.objects.select_for_update().filter(pk=topup_id).first()
    if topup is None:
        raise DomainError("Top-up not found.", code="not_found", status_code=404)
    if topup.status != TopupStatus.PENDING_APPROVAL:
        raise ConflictError("This top-up is not waiting for approval.", code="topup_not_pending")
    if topup.requested_by_id == actor.id:
        raise ForbiddenError("A second admin must approve this top-up.", code="four_eyes_required")
    topup.status, topup.approved_by, topup.approved_at = TopupStatus.APPROVED, actor, timezone.now()
    topup.save(update_fields=["status", "approved_by", "approved_at"])
    _credit_topup(topup, actor)
    audit.record(actor=actor, action="WALLET_TOPUP_APPROVE", obj=topup, after={"amount_minor": topup.amount_minor})
    return topup


@transaction.atomic
def reject_topup(topup_id, *, actor, reason: str) -> WalletTopup:
    """Refuse a pending top-up with a reason; no money moves."""
    if len(reason.strip()) < 10:
        raise DomainError("Give a reason of at least 10 characters.", code="reason_required")
    topup = WalletTopup.objects.select_for_update().filter(pk=topup_id).first()
    if topup is None:
        raise DomainError("Top-up not found.", code="not_found", status_code=404)
    if topup.status != TopupStatus.PENDING_APPROVAL:
        raise ConflictError("This top-up is not waiting for approval.", code="topup_not_pending")
    topup.status, topup.rejection_reason = TopupStatus.REJECTED, reason.strip()
    topup.save(update_fields=["status", "rejection_reason"])
    audit.record(actor=actor, action="WALLET_TOPUP_REJECT", obj=topup, note=reason.strip())
    return topup


# ---------------------------------------------------------------------------
# Commission (BR-PAY-04, BR-PAY-05, DEC-018)
# ---------------------------------------------------------------------------
@transaction.atomic
def post_commission(*, host_account, booking_id, amount_minor: int, reference: str = "") -> LedgerTransaction | None:
    """
    Take the commission of a confirmed booking from the host's deposit.

    Safe to call twice: the second call returns the existing transaction
    (one commission per booking, enforced by a unique constraint).
    Returns ``None`` when the commission is zero.
    """
    if amount_minor <= 0:
        return None
    existing = LedgerTransaction.objects.filter(booking_id=booking_id, kind=TransactionKind.COMMISSION).first()
    if existing:
        return existing
    wallet = wallet_account(host_account)
    revenue = platform_account(AccountKind.COMMISSION_REVENUE)
    return _post(
        kind=TransactionKind.COMMISSION,
        description=f"Commission booking {reference}".strip(),
        lines=[(wallet, amount_minor), (revenue, -amount_minor)],
        wallet_delta={wallet: -amount_minor},
        booking_id=booking_id,
    )


def commission_share_to_return(*, commission_minor: int, commission_base_minor: int, refund_of_base_minor: int) -> int:
    """
    Part of the commission given back when part of the stay is refunded (DEC-018 revised 2026-11-13).

    The commission follows the refund: if half of the accommodation subtotal
    goes back to the guest, half of the commission goes back to the host.
    ``refund_of_base_minor`` is clamped to ``[0, commission_base_minor]``.
    Rounded half up, never more than the commission.
    """
    if commission_minor <= 0 or commission_base_minor <= 0:
        return 0
    part = max(0, min(refund_of_base_minor, commission_base_minor))
    share = (commission_minor * part * 2 + commission_base_minor) // (2 * commission_base_minor)
    return min(share, commission_minor)


@transaction.atomic
def reverse_commission(*, host_account, booking_id, amount_minor: int | None = None,
                       reference: str = "") -> LedgerTransaction | None:
    """
    Give commission back to the host after a cancellation (DEC-018 revised, BR-PAY-05).

    ``amount_minor`` is the share to return (see :func:`commission_share_to_return`);
    ``None`` returns the full commission (host cancellation). Does nothing when
    no commission was taken or the share is zero, and returns the existing
    reversal when one was already posted (one reversal per booking).
    """
    original = LedgerTransaction.objects.filter(booking_id=booking_id, kind=TransactionKind.COMMISSION).first()
    if original is None:
        return None
    already = LedgerTransaction.objects.filter(booking_id=booking_id, kind=TransactionKind.COMMISSION_REVERSAL).first()
    if already:
        return already
    wallet = wallet_account(host_account)
    revenue = platform_account(AccountKind.COMMISSION_REVENUE)
    taken = original.entries.get(account=wallet).amount_minor  # positive debit taken from the wallet
    amount = taken if amount_minor is None else max(0, min(int(amount_minor), taken))
    if amount == 0:
        return None
    return _post(
        kind=TransactionKind.COMMISSION_REVERSAL,
        description=f"Commission returned booking {reference}".strip(),
        lines=[(revenue, amount), (wallet, -amount)],
        wallet_delta={wallet: amount},
        booking_id=booking_id,
        reverses=original,
    )


# ---------------------------------------------------------------------------
# Refund debts (review R8). Memo lines only: the money goes from the host to
# the guest directly (DEC-019); BLADUS records who owes what so it can act
# when a host does not pay.
# ---------------------------------------------------------------------------
def _refund_accounts(host_account) -> tuple[LedgerAccount, LedgerAccount]:
    """The host's refund-payable memo account and the platform clearing memo account."""
    payable, _ = LedgerAccount.objects.get_or_create(
        host_account=host_account, kind=AccountKind.HOST_REFUND_PAYABLE,
        defaults={"code": f"host_refund_payable:{host_account.id}"},
    )
    return payable, platform_account(AccountKind.GUEST_REFUND_CLEARING)


@transaction.atomic
def record_refund_due(*, host_account, booking_id, amount_minor: int, reference: str = "") -> LedgerTransaction | None:
    """Record that the host owes ``amount_minor`` to the guest of ``booking_id``. Safe to call twice."""
    if amount_minor <= 0:
        return None
    existing = LedgerTransaction.objects.filter(booking_id=booking_id, kind=TransactionKind.REFUND_DUE).first()
    if existing:
        return existing
    payable, clearing = _refund_accounts(host_account)
    return _post(
        kind=TransactionKind.REFUND_DUE, description=f"Refund owed to guest, booking {reference}".strip(),
        lines=[(payable, amount_minor), (clearing, -amount_minor)], booking_id=booking_id,
    )


@transaction.atomic
def record_refund_settled(*, host_account, booking_id, reference: str = "", actor=None) -> LedgerTransaction | None:
    """Close the refund debt of a booking once the guest got the money. Safe to call twice."""
    due = LedgerTransaction.objects.filter(booking_id=booking_id, kind=TransactionKind.REFUND_DUE).first()
    if due is None:
        return None
    existing = LedgerTransaction.objects.filter(booking_id=booking_id, kind=TransactionKind.REFUND_SETTLED).first()
    if existing:
        return existing
    payable, clearing = _refund_accounts(host_account)
    amount = due.entries.get(account=payable).amount_minor
    return _post(
        kind=TransactionKind.REFUND_SETTLED, description=f"Refund paid to guest, booking {reference}".strip(),
        lines=[(clearing, amount), (payable, -amount)], booking_id=booking_id, reverses=due, actor=actor,
    )


# ---------------------------------------------------------------------------
# Manual adjustments (review R6): always a second admin, capped amount.
# ---------------------------------------------------------------------------
@transaction.atomic
def create_adjustment(*, host_account, amount_minor: int, reason: str, actor) -> WalletAdjustment:
    """
    Ask for a manual correction of a host deposit (review R6).

    Nothing moves until a different admin approves it. ``amount_minor`` is
    signed and non-zero, at most ``adjustment_max_minor`` in absolute value;
    the reason needs 10 characters or more.
    """
    reason = (reason or "").strip()
    if len(reason) < 10:
        raise DomainError("Give a reason of at least 10 characters.", code="reason_required")
    limit = int(config.get_value("adjustment_max_minor"))
    if amount_minor == 0 or abs(amount_minor) > limit:
        raise DomainError(f"The amount must be non-zero and at most {limit // 100} DZD.", code="invalid_amount")
    adjustment = WalletAdjustment.objects.create(
        host_account=host_account, amount_minor=amount_minor, reason=reason, requested_by=actor
    )
    audit.record(actor=actor, action="WALLET_ADJUSTMENT_CREATE", obj=adjustment,
                 after={"amount_minor": amount_minor, "host_account": str(host_account.id)}, note=reason)
    return adjustment


def _pending_adjustment(adjustment_id) -> WalletAdjustment:
    """Read a pending adjustment under a lock, or raise 404 or 409."""
    adjustment = WalletAdjustment.objects.select_for_update().filter(pk=adjustment_id).first()
    if adjustment is None:
        raise DomainError("Adjustment not found.", code="not_found", status_code=404)
    if adjustment.status != AdjustmentStatus.PENDING_APPROVAL:
        raise ConflictError("This adjustment is not waiting for approval.", code="adjustment_not_pending")
    return adjustment


@transaction.atomic
def approve_adjustment(adjustment_id, *, actor) -> WalletAdjustment:
    """A second admin approves; the deposit moves by the signed amount (review R6)."""
    adjustment = _pending_adjustment(adjustment_id)
    if adjustment.requested_by_id == actor.id:
        raise ForbiddenError("A second admin must approve this adjustment.", code="four_eyes_required")
    lock_wallet(adjustment.host_account)
    adjustment.status, adjustment.approved_by, adjustment.approved_at = AdjustmentStatus.APPROVED, actor, timezone.now()
    adjustment.save(update_fields=["status", "approved_by", "approved_at"])
    wallet = wallet_account(adjustment.host_account)
    other = platform_account(AccountKind.ADJUSTMENTS)
    amount = adjustment.amount_minor
    _post(
        kind=TransactionKind.ADJUSTMENT, description=f"Adjustment: {adjustment.reason[:200]}",
        lines=[(other, amount), (wallet, -amount)], wallet_delta={wallet: amount},
        adjustment=adjustment, actor=actor,
    )
    audit.record(actor=actor, action="WALLET_ADJUSTMENT_APPROVE", obj=adjustment, after={"amount_minor": amount})
    return adjustment


@transaction.atomic
def reject_adjustment(adjustment_id, *, actor, reason: str) -> WalletAdjustment:
    """Refuse a pending adjustment with a reason; nothing moves."""
    reason = (reason or "").strip()
    if len(reason) < 10:
        raise DomainError("Give a reason of at least 10 characters.", code="reason_required")
    adjustment = _pending_adjustment(adjustment_id)
    adjustment.status, adjustment.rejection_reason = AdjustmentStatus.REJECTED, reason
    adjustment.save(update_fields=["status", "rejection_reason"])
    audit.record(actor=actor, action="WALLET_ADJUSTMENT_REJECT", obj=adjustment, note=reason)
    return adjustment


# ---------------------------------------------------------------------------
# Reconciliation (review R11)
# ---------------------------------------------------------------------------
def reconcile_balances(*, fix: bool = False, actor=None) -> list[dict]:
    """
    Recompute every stored wallet balance from its ledger lines and return the differences.

    Each difference is ``{"account", "stored_minor", "computed_minor"}``. With
    ``fix=True`` the stored balance is rewritten to the computed value and an
    audit line is written for each fix (use it only after a human read the
    report). Run every night (command ``reconcile_balances``).
    """
    sums = {
        row["account_id"]: row["total"]
        for row in LedgerEntry.objects.filter(account__kind__in=BALANCED_KINDS)
        .values("account_id").annotate(total=Sum("amount_minor"))
    }
    differences = []
    for account in LedgerAccount.objects.filter(kind__in=BALANCED_KINDS):
        computed = -(sums.get(account.id) or 0)
        balance = AccountBalance.objects.filter(account=account).first()
        stored = balance.balance_minor if balance else 0
        if stored == computed:
            continue
        differences.append({"account": account.code, "stored_minor": stored, "computed_minor": computed})
        if fix:
            with transaction.atomic():
                row, _ = AccountBalance.objects.select_for_update().get_or_create(account=account)
                row.balance_minor = computed
                row.save(update_fields=["balance_minor", "updated_at"])
                audit.record(actor=actor, action="LEDGER_BALANCE_FIX", obj=account,
                             before={"balance_minor": stored}, after={"balance_minor": computed})
    return differences
