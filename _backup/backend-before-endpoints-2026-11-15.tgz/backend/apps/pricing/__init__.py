"""Server-side price quotes."""
